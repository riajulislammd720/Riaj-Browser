Riaj Browser - build steps
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this "Riaj" folder, wait for Gradle sync.
3. Build > Build Bundle(s)/APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
