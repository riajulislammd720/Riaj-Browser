package com.riaj.browser;

import android.app.Activity;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.EditText;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private static final String HOME = "https://www.google.com";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.webview);
        urlBar = findViewById(R.id.urlBar);
        progress = findViewById(R.id.progress);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { urlBar.setText(url); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p == 100 ? View.INVISIBLE : View.VISIBLE);
            }
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        findViewById(R.id.btnForward).setOnClickListener(v -> { if (web.canGoForward()) web.goForward(); });
        findViewById(R.id.btnRefresh).setOnClickListener(v -> web.reload());
        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load(urlBar.getText().toString());
                InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                return true;
            }
            return false;
        });

        Uri data = getIntent().getData();
        web.loadUrl(data != null ? data.toString() : HOME);
    }

    private void load(String in) {
        in = in.trim();
        if (in.isEmpty()) return;
        String url;
        if (in.startsWith("http://") || in.startsWith("https://")) url = in;
        else if (in.contains(".") && !in.contains(" ")) url = "https://" + in;
        else url = "https://www.google.com/search?q=" + Uri.encode(in);
        web.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
